#ifndef TUD_CPPP_BONUS_COLONY_HPP
#define TUD_CPPP_BONUS_COLONY_HPP

class Colony {

  public:
    Colony(bool initial_state) {}

    bool getState() const { return false; }

    void calculateNextState(unsigned int alive_neighbors) {}

    void evolve() {}
};

#endif // TUD_CPPP_BONUS_COLONY_HPP
